To Do 
+ Randomized salt
+ Copy box
+ Page Notes
+ Settings for encryption, etc
+ Intro Page

Maybe
- Comparer 
- Dark mode
- Find&Replace
- Clipboard combiner - harder than it seems to read from clipboard
- Extra copy paste clipboard - harder than it seems to read from clipboard


To Look at
https://chromewebstore.google.com/detail/shortkeys-custom-keyboard/logpjaacgmcbpdkdchjiaagddngobkck