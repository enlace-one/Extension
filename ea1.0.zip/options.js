
function changeTabs(button) {
    return function() {
        const tabButtons = document.querySelectorAll(".tab-button");
        // Remove 'active' class from all tab buttons
        tabButtons.forEach(function (btn) {
            btn.classList.remove("active");
        });

        // Add 'active' class to the clicked tab button
        button.classList.add("active");

        // Get the ID of the tab to show
        const dataTabClass = button.getAttribute("data-tab");

        // Hide all tab contents
        const tabContents = document.querySelectorAll(".tab-content");
        tabContents.forEach(function (content) {
            content.classList.remove("active");
        });

        // Show the tab content with the corresponding ID
        const tabContentToShow = document.getElementsByClassName(dataTabClass);
        const tabContentArray = Array.from(tabContentToShow);

        // Iterate over each element and add the "active" class
        tabContentArray.forEach(element => {
            element.classList.add("active");
        });
    };
}




//////////////////////
// DOMContentLoaded //
//////////////////////

window.addEventListener("DOMContentLoaded", function() {
    

})


///////////////////////
// GoogleDriveSignIn //
///////////////////////

document.addEventListener("googleDriveSignIn", function() {

    // Default to page notes when signed in 
    const contactNotesTabButton = document.querySelector("[data-tab='contact-notes-tab']")
    const pageNotesTabButton = document.querySelector("[data-tab='page-notes-tab']")
    pageNotesTabButton.click()
    pageNotesTabButton.classList.remove("hidden")
    contactNotesTabButton.classList.remove("hidden")
})
