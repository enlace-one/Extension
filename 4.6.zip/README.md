To Do 
+ Randomized salt
+ Copy box
+ Page Notes
+ Settings for encryption, etc
+ Intro Page
+ Regex
+ HTML
+ CSS refeence 
+ Page Notes search
- Javascript
- Clean up unused code
- Python?
- SQL?

- Quick-Reference? So you search something like "split" and git "textafter (excel)", "textbefore (excel)", "split (python)", etc. Checkboxes for what languages you have there. 

Maybe
- Comparer 
- Dark mode
- Find&Replace
- Clipboard combiner - harder than it seems to read from clipboard
- Extra copy paste clipboard - harder than it seems to read from clipboard
- Custom keyboard shortcuts? Inject javascript? 
